package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.print.PrintAttributes;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    TextView textview, textview1, tvinout;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView apple1 = (ImageView) findViewById(R.id.apple1);
        apple1.setOnTouchListener(handleTouch);
        ImageView apple2 = (ImageView) findViewById(R.id.apple2);
        apple2.setOnTouchListener(handleTouch);
        ImageView apple3 = (ImageView) findViewById(R.id.apple3);
        apple3.setOnTouchListener(handleTouch);
        ImageView apple4 = (ImageView) findViewById(R.id.apple4);
        apple4.setOnTouchListener(handleTouch);
        ImageView apple5 = (ImageView) findViewById(R.id.apple5);
        apple5.setOnTouchListener(handleTouch);
        ImageView apple6 = (ImageView) findViewById(R.id.apple6);
        apple6.setOnTouchListener(handleTouch);
        ImageView apple7 = (ImageView) findViewById(R.id.apple7);
        apple7.setOnTouchListener(handleTouch);
        ImageView apple8 = (ImageView) findViewById(R.id.apple8);
        apple8.setOnTouchListener(handleTouch);
        ImageView apple9 = (ImageView) findViewById(R.id.apple9);
        apple9.setOnTouchListener(handleTouch);
        textview = findViewById(R.id.textView1);
        textview1 = findViewById(R.id.textView2);
        tvinout = findViewById(R.id.inout);
        set_quiz();
    }
    public void set_quiz(){
        Random rand = new Random();
        int a = rand.nextInt(5) + 1;
        int b = rand.nextInt(5) + 1;
        textview.setText(""+a);
        textview1.setText(""+b);
    }
    public void zero(View view) {
        int ans = 0;
        CheckAnswer(ans);
    }
    public void one(View view) {
        int ans = 1;
        CheckAnswer(ans);
    }
    public void two(View view) {
        int ans = 2;
        CheckAnswer(ans);
    }
    public void three(View view) {
        int ans = 3;
        CheckAnswer(ans);
    }
    public void four(View view) {
        int ans = 4;
        CheckAnswer(ans);
    }
    public void five(View view) {
        int ans = 5;
        CheckAnswer(ans);
    }
    public void six(View view) {
        int ans = 6;
        CheckAnswer(ans);
    }
    public void seven(View view) {
        int ans = 7;
        CheckAnswer(ans);
    }
    public void eight(View view) {
        int ans = 8;
        CheckAnswer(ans);
    }
    public void nine(View view) {
        int ans = 9;
        CheckAnswer(ans);
    }

    public void CheckAnswer(int ans){
        int a = Integer.parseInt(textview.getText().toString());
        int b = Integer.parseInt(textview1.getText().toString());
        int result = a+b;
        //int user_result = ans;
        if(result==ans) {
            tvinout.setText("CORRECT!");
        }
        else {
            tvinout.setText("INCORRECT");
        }
        }

    private View.OnTouchListener handleTouch = new View.OnTouchListener() {
        float dX, dY;

        @Override
        public boolean onTouch(View view, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    dX = view.getX() - event.getRawX();
                    dY = view.getY() - event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    view.animate()
                            .x(event.getRawX() + dX)
                            .y(event.getRawY() + dY)
                            .setDuration(0)
                            .start();
                    break;
                default:
                    return false;
            }
            return true;
        }
    };

}
