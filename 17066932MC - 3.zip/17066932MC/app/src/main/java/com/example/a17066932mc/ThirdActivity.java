package com.example.a17066932mc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ThirdActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three);
    }

    public void playAgain(View view) {
        Intent myIntent = new Intent(view.getContext(),MainActivity.class);
        startActivity(myIntent);
    }
}
