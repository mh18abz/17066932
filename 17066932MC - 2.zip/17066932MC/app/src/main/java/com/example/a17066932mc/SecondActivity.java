package com.example.a17066932mc;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.text.BreakIterator;
import java.util.Random;

public class SecondActivity extends AppCompatActivity {
    
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);
    }

    public void playAgain(View view) {
        Intent myIntent = new Intent(view.getContext(),MainActivity.class);
        startActivity(myIntent);
    }

}
